!function(){var e=location.href.replace(/([?&])fbclid=[0-9a-zA-Z_-]{40,}(?:&|$)/,"$1").replace(/[?&]$/,"");e!=location.href&&history.replaceState(null,"",e)}();
