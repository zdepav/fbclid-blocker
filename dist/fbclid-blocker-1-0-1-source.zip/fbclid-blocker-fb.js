(function(){
    function cleanup(uri) {
        var m = uri.match(/^https?:\/\/lm?\.facebook\.com\/l\.php\?u=([^&]+)(?:&|$)/);
        return (m ? decodeURIComponent(m[1]) : uri)
            .replace(/([\?&])fbclid=[0-9a-zA-Z_-]{40,}(?:&|$)/, "$1")
            .replace(/[\?&]$/, "");
    }
    function fix() {
        for (var a of document.getElementsByTagName("a")) {
            a.href = cleanup(a.href);
            if (a.hasAttribute("data-lynx-uri")) {
                a.setAttribute("data-lynx-uri", cleanup(a.getAttribute("data-lynx-uri")));
            }
        }
        window.setTimeout(fix, 3000);
    }
    window.setTimeout(fix, 2000);
})();
