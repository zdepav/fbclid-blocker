(function() {
    var cleanLocation =
        location.href
            .replace(/([\?&])fbclid=[0-9a-zA-Z_-]{40,}(?:&|$)/, "$1")
            .replace(/[\?&]$/, "");
    if (cleanLocation != location.href) {
        history.replaceState(null, '', cleanLocation);
    }
})();
