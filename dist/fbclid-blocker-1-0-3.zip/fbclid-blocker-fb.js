(function(){
    function cleanup(uri) {
        if (!uri) {
            return uri;
        }
        let m = uri.match(/^https?:\/\/lm?\.facebook\.com\/l\.php\?(?:(?:[^u=]|u[^=]+)=[^&]+&)*u=([^&]+)(?:&|$)/);
        return (m ? decodeURIComponent(m[1]) : uri)
            .replace(/([\?&])fbclid=[0-9a-zA-Z_-]{40,}(?:&|$)/, "$1")
            .replace(/[\?&]$/, "");
    }
    function fix() {
        try {
            for (let a of document.getElementsByTagName("a")) {
                let href = a.getAttribute("href");
                if (!href || href == '#') {
                    continue;
                }
                a.setAttribute("href", cleanup(href));
                if (a.hasAttribute("data-lynx-uri")) {
                    a.setAttribute("data-lynx-uri", cleanup(a.getAttribute("data-lynx-uri")));
                }
            }
            window.setTimeout(fix, 3000);
        } catch (error) {
            console.error("FbclidBlocker error:");
            console.error(error);
        }
    }
    window.setTimeout(fix, 2000);
    console.log("FbclidBlocker initialized");
})();
