(function(){
    function cleanup(uri) {
        let m = uri.match(/^https?:\/\/lm?\.facebook\.com\/l\.php\?u=([^&]+)(?:&|$)/);
        return (m ? decodeURIComponent(m[1]) : uri)
            .replace(/([\?&])fbclid=[0-9a-zA-Z_-]{40,}(?:&|$)/, "$1")
            .replace(/[\?&]$/, "");
    }
    function fix() {
        for (let a of document.getElementsByTagName("a")) {
            let href = a.getAttribute("href");
            if (href == '#') {
                continue;
            }
            a.setAttribute("href", cleanup(href));
            if (a.hasAttribute("data-lynx-uri")) {
                a.setAttribute("data-lynx-uri", cleanup(a.getAttribute("data-lynx-uri")));
            }
        }
        window.setTimeout(fix, 3000);
    }
    window.setTimeout(fix, 2000);
})();
